/*
 * main.c
 *
 *  Created on: May 22, 2024
 *      Author: Hadeer Shrif
 *              Mariam Hatem
 */



#include "Bit_Operations.h"
#include "Std_Types.h"
#include "Utils.h"
#include "Gpio.h"
#include "Rcc.h"
#include "Nvic.h"
#include "Exti.h"

#define SYSCFG_BASE_ADDRESS 0x40013800
#define SYSCFG ((SYSCFG_TypeDef *) SYSCFG_BASE_ADDRESS)

typedef struct {
    uint32 MEMRMP;
    uint32 PMC;
    uint32 EXTICR[4];
    uint32 RESERVED1[2];
    uint32 CMPCR;
    uint32 RESERVED2[2];
    uint32 CFGR;
} SYSCFG_TypeDef;

#define EXTI_BASE_ADDRESS (0x40013C00)
#define EXTI ((ExtiType *) EXTI_BASE_ADDRESS)

// Definitions for GPIO pins and IRQ numbers
#define BUTTON1_PIN 9
#define BUTTON2_PIN 5
#define BUTTON1_PORT GPIO_A
#define BUTTON2_PORT GPIO_B
#define BUTTON1_IRQ 23 // EXTI line 9_5 interrupt vector position
#define BUTTON2_IRQ 23 // EXTI line 9_5 interrupt vector position

// Definitions for seven-segment display
#define SEVEN_SEGMENT_PORT GPIO_A
#define SEGMENT_A_PIN 0
#define SEGMENT_B_PIN 1
#define SEGMENT_C_PIN 2
#define SEGMENT_D_PIN 3
#define SEGMENT_E_PIN 4
#define SEGMENT_F_PIN 5
#define SEGMENT_G_PIN 6

// Global counter variable
volatile int counter = 0;

// Seven-segment display digit encoding
uint8 seven_segment_encoding[10] = {
    0b00111111, // 0
    0b00000110, // 1
    0b01011011, // 2
    0b01001111, // 3
    0b01100110, // 4
    0b01101101, // 5
    0b01111101, // 6
    0b00000111, // 7
    0b01111111, // 8
    0b01101111  // 9
};

// Function prototypes
void Display_SetDigit(int digit);
void Delay(uint32 ms);

int main() {
    // Initialize RCC and enable necessary peripherals
    Rcc_Init();
    Rcc_Enable(RCC_GPIOA);
    Rcc_Enable(RCC_GPIOB);
    Rcc_Enable(RCC_SYSCFG);

    // Configure GPIO pins for buttons
    Gpio_ConfigPin(BUTTON1_PORT, BUTTON1_PIN, GPIO_INPUT, GPIO_PULL_UP);
    Gpio_ConfigPin(BUTTON2_PORT, BUTTON2_PIN, GPIO_INPUT, GPIO_PULL_UP);

    // Configure GPIO pins for seven-segment display
    for (int i = SEGMENT_A_PIN; i <= SEGMENT_G_PIN; i++) {
        Gpio_ConfigPin(SEVEN_SEGMENT_PORT, i, GPIO_OUTPUT, GPIO_PUSH_PULL);
    }

    // Configure EXTI for buttons
    Exti_Init(BUTTON1_PIN, EXTI_TRIGGER_FALLING_EDGE);
    Exti_Init(BUTTON2_PIN, EXTI_TRIGGER_FALLING_EDGE);

    // Map EXTI lines to GPIO ports
    SYSCFG->EXTICR[BUTTON1_PIN / 4] &= ~(0xF << ((BUTTON1_PIN % 4) * 4));
    SYSCFG->EXTICR[BUTTON1_PIN / 4] |= (0 << ((BUTTON1_PIN % 4) * 4)); // Map EXTI line to PA9
    SYSCFG->EXTICR[BUTTON2_PIN / 4] &= ~(0xF << ((BUTTON2_PIN % 4) * 4));
    SYSCFG->EXTICR[BUTTON2_PIN / 4] |= (1 << ((BUTTON2_PIN % 4) * 4)); // Map EXTI line to PB5

    // Enable EXTI lines
    Exti_Enable(BUTTON1_PIN);
    Exti_Enable(BUTTON2_PIN);

    // Enable interrupts in NVIC
    Nvic_EnableInterrupt(BUTTON1_IRQ);
    Nvic_EnableInterrupt(BUTTON2_IRQ);

    while (1) {
        // Display the counter value on the seven-segment display
        Display_SetDigit(counter);
        // Add a delay to slow down the display update rate
        Delay(200); // Adjust the delay as needed
    }

    return 0;
}

// ISR for button 1 (increment counter)
void EXTI9_5_IRQHandler(void) {
    // Check if interrupt is from BUTTON1_PIN
    if (EXTI->PR & (1 << BUTTON1_PIN)) {
        // Clear the interrupt pending flag
        EXTI->PR |= (1 << BUTTON1_PIN);

        // Increment counter
        if (counter < 9) {
            counter++;
        }
    }

    // Check if interrupt is from BUTTON2_PIN
    if (EXTI->PR & (1 << BUTTON2_PIN)) {
        // Clear the interrupt pending flag
        EXTI->PR |= (1 << BUTTON2_PIN);

        // Decrement counter
        if (counter > 0) {
            counter--;
        }
    }
}

// Function to display a digit on the seven-segment display
void Display_SetDigit(int digit) {
    if (digit < 0 || digit > 9) {
        return; // Invalid digit
    }

    uint8 segments = seven_segment_encoding[digit];

    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_A_PIN, segments & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_B_PIN, (segments >> 1) & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_C_PIN, (segments >> 2) & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_D_PIN, (segments >> 3) & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_E_PIN, (segments >> 4) & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_F_PIN, (segments >> 5) & 0x01);
    Gpio_WritePin(SEVEN_SEGMENT_PORT, SEGMENT_G_PIN, (segments >> 6) & 0x01);
}

// Simple delay function (blocking)
void Delay(uint32 ms) {
    for (uint32 i = 0; i < ms * 4000; i++) {
        __asm("nop"); // No operation (just wasting time)
    }
}
