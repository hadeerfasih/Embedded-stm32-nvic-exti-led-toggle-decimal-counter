/**
 * Nvic.h
 *
 *  Created on: May 22, 2024
 *      Author: Hadeer Shrif
 *              Mariam Hatem
 */

#ifndef NVIC_H
#define NVIC_H

#include "Std_Types.h"

void Nvic_EnableInterrupt(uint8 IRQn);

void Nvic_DisableInterrupt(uint8 IRQn);

#endif /* NVIC_H */
