/**
 * Nvic.c
 *
 *  Created on: May 22, 2024
 *      Author: Hadeer Shrif
 *              Mariam Hatem
 */

#include "Nvic.h"

#include "Bit_Operations.h"

#define NVIC_BASE (0xE000E100)

volatile uint32* NVIC_ISER[] = {
    (uint32*)0xE000E100, (uint32*)0xE000E104, (uint32*)0xE000E108
};

volatile uint32* NVIC_ICER[] = {
    (uint32*)0xE000E180, (uint32*)0xE000E184, (uint32*)0xE000E188
};

void Nvic_EnableInterrupt(uint8 IRQn) {
	uint8 index = IRQn / 32;
	uint8 bit_position = IRQn % 32;
	NVIC_ISER[index][0] |= (1U << bit_position);
}

void Nvic_DisableInterrupt(uint8 IRQn) {
	uint8 index = IRQn / 32;
	uint8 bit_position = IRQn % 32;
	NVIC_ICER[index][0] |= (1U << bit_position);
}
