/*
 * Exti.c
 *
 *  Created on: May 22, 2024
 *      Author: Mariam Hatem
 *              Hadeer Shrif
*/
#include "Exti.h"
#include "Bit_Operations.h"

#define EXTI_BASE_ADDRESS (0x40013C00)



volatile ExtiType* EXTI = (ExtiType*)EXTI_BASE_ADDRESS;

void Exti_Init(uint8 line, uint8 triggerType) {
    // Disable EXTI line
    Exti_Disable(line);

    // Configure the trigger type (rising edge, falling edge, or both)
    if (triggerType == EXTI_TRIGGER_RISING_EDGE) {
        SET_BIT(EXTI->RTSR, line);
        CLEAR_BIT(EXTI->FTSR, line);
    } else if (triggerType == EXTI_TRIGGER_FALLING_EDGE) {
        CLEAR_BIT(EXTI->RTSR, line);
        SET_BIT(EXTI->FTSR, line);
    } else if (triggerType == EXTI_TRIGGER_BOTH_EDGES) {
        SET_BIT(EXTI->RTSR, line);
        SET_BIT(EXTI->FTSR, line);
    }
}

void Exti_Enable(uint8 line) {
    SET_BIT(EXTI->IMR, line);
}

void Exti_Disable(uint8 line) {
    CLEAR_BIT(EXTI->IMR, line);
}
