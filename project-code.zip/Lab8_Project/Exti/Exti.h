/*
 * Exti.h
 *
 *  Created on: May 22, 2024
 *      Author: Mariam Hatem
 *              Hadeer Shrif
*/
#ifndef EXTI_H_
#define EXTI_H_

#include "Std_Types.h"

/* Trigger types for EXTI */
#define EXTI_TRIGGER_RISING_EDGE   0
#define EXTI_TRIGGER_FALLING_EDGE  1
#define EXTI_TRIGGER_BOTH_EDGES    2

typedef struct {
    uint32 IMR;
    uint32 EMR;
    uint32 RTSR;
    uint32 FTSR;
    uint32 SWIER;
    uint32 PR;
} ExtiType;

void Exti_Init(uint8 line, uint8 triggerType);

void Exti_Enable(uint8 line);

void Exti_Disable(uint8 line);

#endif /* EXTI_H_ */
